library(xlsx)
library(openxlsx)
library(nortest)
library(car)
library(dunn.test)
setwd("")
datos <- read.table("metadata.tsv",header = TRUE,sep = "\t")
datos <- subset(datos,datos$Sample=="Stool")

#limpiamos el data frame y transformamos las variables chr a factor

datos<-datos[,3:23]
datos <- datos[,-2]
datos <- datos[,-(12:13)]
str(datos)

#Primero trabajamos las variables numericas
#Seleccionamos las numericas y añadimos la variable grupo (factor)
col_num <- datos[,sapply(datos,is.numeric)]
v_numericas <- datos[,c("Group",names(col_num))]
v_numericas$Group<-as.factor(v_numericas$Group)


normalidad_homocedasticidad <- function(data,variable,grupo){
  normalidad <- by(data[[variable]],data[[grupo]],FUN = shapiro.test)
  
  homocedasticidad <- leveneTest(data[[variable]]~data[[grupo]])
  
  # Imprimir resultados
  print("Prueba de normalidad (Shapiro-Wilk) por grupo:")
  print(normalidad)
  
  print("\nPrueba de homocedasticidad (Levene):")
  print(homocedasticidad)
  ##SEGURAMENTE SE PUEDAN GUARDAR ESTOS VALORES Y PASARLOS POR LA FUNCION DIRECTAMENTE
}

funcion_anova <- function(data,variable,grupo){
  a_variable <- aov(data[[variable]]~data[[grupo]])
  summary(a_variable)
  
  #guardamos el p value para hacer postestimacion
  valor_p <- summary(a_variable)[[1]]$`Pr(>F)`[1]
  if (valor_p <= 0.05) {
    TukeyHSD(a_variable,'data[[grupo]]')
  } else  {
    print("No hay diferencias significativas")
  }
}

funcion_kruskal <- function(data,variable,grupo){
  test_k <- kruskal.test(data[[variable]]~data[[grupo]])
  
  #guardamos el p value para hacer postestimacion
  valor_pk <- test_k$p.value
  if (valor_pk <= 0.05) {
    dunn.test(x=data[[variable]],
                         g=data[[grupo]],
                         method = "bonferroni")
  } else {
    print("No hay diferencias significativas")
  }
}

#Age
normalidad_homocedasticidad(v_numericas,"Age","Group")
funcion_anova(v_numericas,"Age","Group")
#*** para todas las comparaciones

#Lymphocytes
normalidad_homocedasticidad(v_numericas,"Lymphocytes","Group")
funcion_anova(v_numericas,"Lymphocytes","Group")

#Neutrofilos
normalidad_homocedasticidad(v_numericas,"Neutrophils","Group")
funcion_kruskal(v_numericas,"Neutrophils","Group")

#plaquetas
normalidad_homocedasticidad(v_numericas,"Platelets","Group")
funcion_kruskal(v_numericas,"Platelets","Group")
#** para mild vs moderate y significativo para mild vs severe

#Dimero D
normalidad_homocedasticidad(v_numericas,"D.dimer","Group")
kruskal.test(v_numericas,"D.dimer","Group")
#difs

#Ferritina
normalidad_homocedasticidad(v_numericas,"Ferritin","Group")
funcion_kruskal(v_numericas,"Ferritin","Group")
#muy significativo mild vs severe y moderate y significativo moderate vs  severe

#CRP
normalidad_homocedasticidad(v_numericas,"CRP","Group")
funcion_kruskal(v_numericas,"CRP","Group")
#Considerando que no es normal hay difs *** para todos. 


#Ahora trabajamos las variables categoricas
#Las seleccionamos y las transformarmos a factor

col_chr <- datos[,sapply(datos,is.character)]
v_categoricas <- datos[,c(names(col_chr))]

factor_cols <- sapply(v_categoricas, is.character) #identificamos las chr
for (i in names(v_categoricas)[factor_cols]) { #para cada nombre guardado en la variable con las chr
  v_categoricas[[i]] <- factor(v_categoricas[[i]]) #y se transforma cada variable a factor con dichos niveles
}
str(v_categoricas)


funcion_fisher <- function(data,variable,grupo){
  # Crear una lista para almacenar los resultados de Fisher's Exact Test por par de grupos
  resultados_fisher_por_grupo <- list()
  
  # Obtener los niveles únicos de la variable "Group"
  niveles_grupo <- unique(data[[grupo]])
  
  # Realizar Fisher's Exact Test para cada par de grupos.     El primer bucle for (for (i in 1:(length(niveles_grupo) - 1))) 
  #selecciona un grupo en cada iteración, comenzando desde el primer grupo ("Mild" en la primera iteración)
  #hasta el penúltimo grupo ("Moderate" en la última iteración).
  #El segundo bucle for (for (j in (i+1):length(niveles_grupo))) selecciona el segundo grupo en cada 
  #iteración, pero comienza desde el grupo siguiente al seleccionado en el primer bucle. 
  #Esto evita la duplicación de comparaciones.
  
  for (i in 1:(length(niveles_grupo) - 1)) {
    for (j in (i+1):length(niveles_grupo)) {
      grupo1 <- niveles_grupo[i]
      grupo2 <- niveles_grupo[j]
      
      # Filtrar los datos para los dos grupos
      datos_grupo1 <- subset(data, data[[grupo]] == grupo1)
      datos_grupo2 <- subset(data, data[[grupo]] == grupo2)
      
      # Crear una tabla de contingencia para Gender en cada grupo
      tabla_contingencia_grupo1 <- table(datos_grupo1[[variable]])
      tabla_contingencia_grupo2 <- table(datos_grupo2[[variable]])
      
      # Realizar Fisher's Exact Test para comparar los grupos
      resultado_fisher_grupo <- fisher.test(rbind(tabla_contingencia_grupo1, tabla_contingencia_grupo2))
      
      # Almacenar el resultado en la lista
      nombres_grupos <- paste(grupo1, "-", grupo2)
      resultados_fisher_por_grupo[[nombres_grupos]] <- resultado_fisher_grupo
    }
  }
  
  # Imprimir los resultados de Fisher's Exact Test para cada par de grupos
  for (nombres_grupos in names(resultados_fisher_por_grupo)) {
    print(paste("Comparación entre grupos:", nombres_grupos))
    print(resultados_fisher_por_grupo[[nombres_grupos]])
  }
}

funcion_fisher(v_categoricas,"Cardiomyopathy","Group")



# Obtener las frecuencias y porcentajes de las variables categóricas por grupo
frecuencias <- sapply(datos_ns[, factor_cols], function(x) table(x, datos_ns$Group))
porcentajes <- sapply(frecuencias, function(x) prop.table(x, margin = 1) * 100)

# Crear una lista para almacenar los resultados
resultados <- list()

# Realizar el test de chi-cuadrado para cada variable categórica
for (i in seq_along(frecuencias)) {
  tabla_contingencia <- frecuencias[[i]]
  
  # Verificar el número de elementos en la tabla de contingencia
  if (length(tabla_contingencia) >= 2) {
    resultado_test <- chisq.test(tabla_contingencia)
    
    # Agregar los resultados al objeto "resultados"
    resultados[[i]] <- list(
      Categoria = names(frecuencias)[i],
      Frecuencia = tabla_contingencia,
      Porcentaje = porcentajes[[i]],
      Test_Chi2 = resultado_test$statistic,
      Valor_p = resultado_test$p.value
    )
  }
}

# Imprimir los resultados
for (i in seq_along(resultados)) {
  print(resultados[[i]])
}

