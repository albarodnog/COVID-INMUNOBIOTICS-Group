#paquetes necesarios para realizar el analisis de microbiota
library(microbiome)
library(tidyr)
library(stringr)
library(phyloseq)
library(dplyr)
library(ggplot2)
library(vegan)

#establecemos el directorio de trabajo
setwd("")


#cargamos la tabla con los OTUs/ASVs obtenidos mediante Deblur/DADA2 
otu <- read.table(file = "feature-table.tsv", sep = "\t", header = T,
                  row.names = 1, 
                  skip = 1, comment.char = "",
                  check.names = FALSE) #añadimos check.names para evitar problemas con los nombres

#cargamos la taxonomia obtenida en este caso mediante base de datos SILVA
taxonomy <- read.table(file = "taxonomy.tsv", sep = "\t", header = T ,
                       row.names = 1, check.names = FALSE)
#Hay que separar la segunda columna en 7 (formato SILVA)
tax <- taxonomy %>% #creamos nueva variable llamada tax
  select(Taxon) %>% #seleccionamos la segunda columna de taxonomy
  separate(Taxon, c("Domain", "Phylum", "Class", "Order", "Family", 
                    "Genus", "Species"), "; ") #indicamos que separe dicha columna en x veces mediante ;

#El siguiente paso es eliminar los k__,p__,c__, etc. 
#str_replace cambia la estructura primera por nada en este caso.

tax.clean<-data.frame(row.names = row.names(tax),
                      Domain = str_replace(tax[,1], "d__",""),
                      Phylum = str_replace(tax[,2], "p__",""),
                      Class = str_replace(tax[,3], "c__",""),
                      Order = str_replace(tax[,4], "o__",""),
                      Family = str_replace(tax[,5], "f__",""),
                      Genus = str_replace(tax[,6], "g__",""),
                      Species = str_replace(tax[,7], "s__",""),
                      stringsAsFactors = FALSE)
tax.clean[is.na(tax.clean)] <- "" #cambiar los NA por vacio
tax.clean[tax.clean=="__"] <- "" #cambiar por nada los guiones bajos

for (i in 1:nrow(tax.clean)){
  if (tax.clean[i,2] == ""){
    domain <- paste("Unclassified", tax.clean[i,1], sep = " ")
    tax.clean[i, 2:7] <- domain
  } else if (tax.clean[i,3] == ""){
    phylum <- paste("Unclassified", tax.clean[i,2], sep = " ")
    tax.clean[i, 3:7] <- phylum
  } else if (tax.clean[i,4] == ""){
    class <- paste("Unclassified", tax.clean[i,3], sep = " ")
    tax.clean[i, 4:7] <- class
  } else if (tax.clean[i,5] == ""){
    order <- paste("Unclassified", tax.clean[i,4], sep = " ")
    tax.clean[i, 5:7] <- order
  } else if (tax.clean[i,6] == ""){
    family <- paste("Unclassified", tax.clean[i,5], sep = " ")
    tax.clean[i, 6:7] <- family
  } else if (tax.clean[i,7] == ""){
    tax.clean$Species[i] <- paste("Unclassified ",tax.clean$Genus[i], sep = " ")
  }
}

#Nos quedamos solo con las bacterias:

tax.clean2 <- subset(tax.clean,tax.clean$Domain == "Bacteria")

#cargar la informacion de cada muestra
metadata <- read.table(file = "metadata.tsv", sep = "\t",
                       header = T, row.names = 1,
                       check.names = FALSE)


#Generar variables para paquete Phyloseq
OTU = otu_table(as.matrix(otu), taxa_are_rows = TRUE)
TAX = tax_table(as.matrix(tax.clean2))
SAMPLE = sample_data(metadata_heces)
TREE = read_tree("tree.nwk")

#objeto phyloseq con toda la informacion
ps <- phyloseq(OTU, TAX, SAMPLE,TREE)

##COMIENZO DEL ANALISIS


set.seed(111) # keep result reproductive
ps.rarefied = rarefy_even_depth(ps, rngseed=1, sample.size= 25000, replace=F)

#damos formato de factor a los grupos de estudio
sample_data(ps.rarefied)$Group<-factor(sample_data(ps.rarefied)$Group,
                                        c("Mild","Moderate","Severe"))

colors_g <- c('Mild'='green','Moderate'='lightblue','Severe'='red')

#ALFA DIVERSIDAD
#código de gŕafico para la diversidad

diversidad<-plot_richness(ps.rarefied, x="Group", measures=c("Observed", "Shannon",
                                                 "InvSimpson"),
              color = "Group") +
  geom_boxplot(outlier.colour = "Black",alpha=0.1) +
  #facet_wrap(~Sample,scales = c("fixed")) +
  theme_classic() +
  theme(legend.position = "none",
        strip.background = element_blank(), axis.text.x.bottom = element_text(angle = 45,
                                                                              size = 8,
                                                                              hjust = 1,
                                                                              face = 'bold'))+
  scale_color_manual(values=colors_g)
tiff("diversidad.tiff", width = 3, height = 3, units = "in", res = 300)
print(diversidad)
dev.off() 

#sacamos los datos a una tabla para poder hacer estadistica
rich = estimate_richness(ps.rarefied, measures = c("Observed", "Shannon","InvSimpson"))
#seleccionamos el nombre de las filas
Muestra<-rownames(rich)
#juntamos los nombres con la estimacion de alfa diversidad
R<-cbind(Muestra,rich)
#asociamos la muestra al grupo
Muestra<-rownames(metadata)
M<-cbind(Muestra,metadata)
#combinamos ambas tablas
RICH<-dplyr::inner_join(M,R, by="Muestra")

##CORRELACIONES ALFA DIVERSIDAD
#rocesamos la tabla para quitar las variables sin interes:cirrosis,y demas
library(tidyverse)
RICH <- RICH[,-(15:16)]
RICH <- RICH[,-(22)]
RICH <- RICH[,-(1:2)]
RICH <- RICH[,-(2)]
RICH <- RICH[,-(19)]
RICH <- RICH[,-(20)]


factor_cols <- sapply(names(RICH), function(col) is.character(RICH[[col]]) && col != "Group")
for (i in names(RICH)[factor_cols]) {
  levels <- unique(RICH[[i]])
  RICH[[i]] <- as.integer(factor(RICH[[i]], levels = levels))
  attr(RICH[[i]], "labels") <- levels
}
str(RICH)

#se puede guardar el archivo si queremos
library(xlsx)
write.xlsx(RICH,"alfa_diversity.xlsx")
RICH<-read.xlsx(file = "alfa_diversity.xlsx",header = TRUE,sheetIndex = 1)

#cargamos los paquetes de estadistica
library(nortest)
library(car)
library(ARTool)
library(stats)
library(dunn.test)

#a las variables categoricas STATUS e IBD les damos forma de factor para poder hacer estadistica
#for (i in 2:3) {
# RICH[,i]<-as.factor(RICH[,i])
#}
RICH$Group<-factor(RICH$Group,c("Mild","Moderate","Severe"))
RICH$Sample<-factor(RICH$Sample,c("Nasal swab","Stool"))
RICH$Patient<-as.factor(RICH$Patient)
str(RICH)

#ALFA
by(data = RICH,INDICES = RICH$Group,FUN = function(x){sf.test(x$Observed)})
leveneTest(RICH$Observed~RICH$Group)
kruskal.test(Observed~Group,RICH)
#No difs

#Shannon
by(data = RICH,INDICES = RICH$Group,FUN = function(x){sf.test(x$Shannon)})
leveneTest(RICH$Shannon~RICH$Group)
kruskal.test(Shannon~Group,RICH)
dunn.test(RICH$Shannon, RICH$Group, method = "bonferroni")

#InvSimpson
by(data = RICH,INDICES = RICH$Group,FUN = function(x){sf.test(x$InvSimpson)})
leveneTest(RICH$InvSimpson~RICH$Group)
kruskal.test(InvSimpson~Group,RICH)
#casi sig (0.0935)

#BETA DIVERSIDAD
ps_log <- transform_sample_counts(ps.rarefied, function(x) log(1 + x))
# making ordinate (seleccionamos la distancia a medir)
out_wuf_log <- ordinate(ps_log, 
                        method = "PCoA", # for PCoA 
                        distance = "unifrac",
                        weighted = TRUE) # weighted Unifrac distance

# prepare eigen values to adjust axis
evals <- out_wuf_log$values$Eigenvalues
# hacemos la grafica teniendo en cuenta los grupos como colores
plot_pcoa<- plot_ordination(ps_log, out_wuf_log, color = "Group") +
  geom_point(size=5, alpha=0.75) +
  coord_fixed(sqrt(evals[2] / evals[1])) +
  #stat_ellipse(type = "norm", linetype = 2) +
  stat_ellipse(type = "t") +
  theme_classic() +
  labs(x="PCoA_Wunifrac 1",y="PCoA_Wunifrac 2")
plot_pcoa

#bray distance
out_bray_log <- ordinate(ps_log, 
                         method = "PCoA", # for PCoA 
                         distance = "bray")
# prepare eigen values to adjust axis
evals_bray <- out_bray_log$values$Eigenvalues
plot_pcoa2<- plot_ordination(ps_log, out_bray_log, color = "Group") +
  geom_point(size=2, alpha=0.75) +
  coord_fixed(sqrt(evals_bray[2] / evals_bray[1])) +
  #stat_ellipse(type = "norm", linetype = 2) +
  stat_ellipse(type = "t") +
  theme_classic() +
  labs(x="PCoA_BC 1",y="PCoA_BC 2") +
  scale_color_manual(values = c("green","lightblue","red"))
plot_pcoa2

#unifrac unweighted
out_uf_log <- ordinate(ps_log, 
                       method = "PCoA", # for PCoA 
                       distance = "unifrac",
                       weighted = FALSE) # unweighted Unifrac distance
# prepare eigen values to adjust axis
evals_uw <- out_uf_log$values$Eigenvalues
plot_pcoa3 <- plot_ordination(ps_log, out_uf_log, color = "Group") +
  geom_point(size=5, alpha=0.75) +
  coord_fixed(sqrt(evals_uw[2] / evals_uw[1])) +
  #stat_ellipse(type = "norm", linetype = 2) +
  stat_ellipse(type = "t") +
  theme_classic() +
  labs(x="PCoA_Unifrac 1",y="PCoA_Unifrac 2") +
  scale_color_manual(values = c("Green","Blue","Red"))
plot_pcoa3

tiff("bray_curtis.tiff", width = 4, height = 7, units = "in", res = 300)
print(plot_pcoa2)
dev.off() 


#calculamos las distancias en forma de tabla para poder hacer estadistica
dist = phyloseq::distance(ps_log,method = "wunifrac")
metadata <- data.frame(sample_data(ps_log))
test.adonis <- adonis(dist ~ Group,data = metadata)
test.adonis <- as.data.frame(test.adonis$aov.tab)
test.adonis

#significativo. 
library(pairwiseAdonis)
pairwise.adonis(dist,metadata$Group)
#Sig para todo

dist_2 = phyloseq::distance(ps_log,method = "bray")
test.adonis2<-adonis(dist_2~Group,data = metadata)
test.adonis2<-as.data.frame(test.adonis2$aov.tab)
test.adonis2
#bray_curtis: 0.001
#cargamos paquete pairwise.adonis y miramos el resultado. Quiere decir que los centroides de los grupos son distintos
pairwise.adonis(dist_2,metadata$Group)
#Significativo para todas las comparaciones

dist_3 = phyloseq::distance(ps_log,method = "unifrac")
test.adonis3<-adonis(dist_3~Group,data = metadata)
test.adonis3<-as.data.frame(test.adonis3$aov.tab)
test.adonis3
#singificativo 
pairwise.adonis(dist_3,metadata$Group)
#Significativo para todo


#RELATIVE ABUNDANCE
#https://david-barnett.github.io/microViz/articles/web-only/heatmaps.html


#en primer lugar normalizamos la abundancia
ps.rel = transform_sample_counts(ps.rarefied, function(x) x/sum(x)*100)

# mediante esta función seleccionamos el rango que deseamos estudiar

glom <- tax_glom(ps.rel, taxrank = 'Phylum', NArm = FALSE)
ps.melt <- psmelt(glom) #transformamos objeto phyloseq a un data.frame

#asegurarnos que la variable filo, genero, etc está en formato character.

ps.melt <- ps.melt %>%
  group_by(Group,Patient,Phylum) %>% #agrupar las variables que deseemos. En este caso tiene en cuenta donde coincida el grupo y el filo
  mutate(median=median(Abundance)) #creamos una nueva variable que es median

ps.melt_sum <- ps.melt %>%
  group_by(Group,Patient,Phylum) %>% #creamos una nueva variable "summarise" teniendo en cuenta estas tres que coincidan
  summarise(Abundance= sum(Abundance))

ps.melt_sum <-subset(ps.melt_sum,ps.melt_sum$Abundance > 2)
ps.melt_sum$Phylum <- sub("Proteobacteria", "Pseudomonadota", ps.melt_sum$Phylum)
#ahora podemos representar los resultados mediante barplot acumulado

filo<-ggplot(ps.melt_sum, aes(x = Group, y = Abundance, fill = Phylum)) + 
  geom_bar(stat = "identity",position = 'fill') + #se usa position fill para ajusar el eje y y que tenga en cuenta el porcentaje.
  labs(x="", y="Abundance (%)") +
  #facet_wrap(~Group,scales = "fixed") + #este codigo es por si hubiese 2x2 factores
  theme_classic() + 
  theme(strip.background = element_blank(), 
        axis.text.x.bottom = element_text(angle = 45,
                                          size = 8,
                                          hjust = 1,
                                          face = 'bold'),
        strip.text.x = element_text(size = 10)) +
  scale_fill_viridis_d()+
  scale_y_continuous(labels = scales::percent_format())
filo
tiff("filo_stool_bp.tiff", width = 6, height = 6, units = "in", res = 300)
print(filo)
dev.off() 

filos <- c('Actinobacteriota','Bacillota','Bacteroidota','Pseudomonadota')

ps.melt_sum <- ps.melt_sum %>%
  filter(Phylum %in% filos)

filo <- ggplot(ps.melt_sum,aes(x=Group,y=Abundance,fill=Group))+
  geom_boxplot()+
  facet_wrap(~Phylum,scales = 'fixed')+
  theme_classic()+
  labs(x='',y='Relative Abundance (%)')+
  theme(axis.text.x.bottom = element_text(angle = 45,
                                          size = 8,
                                          hjust = 1,
                                          face = 'bold'),
        strip.text.x = element_text(size = 10))+
  scale_fill_manual(values = colors_g)
filo

tiff('filo_barplot.tiff',width=6,height=6,units = 'in',res=300)
print(filo)
dev.off()


#Generamos una lista con x numero de filos mediante el comando split

filos <- split(ps.melt_sum,ps.melt_sum$Phylum)
#creamos una variable con los nombres de cada elemento de la lista
filos_names <- names(filos)

#hacemos un bucle que vaya de 1 al total de la lista y que en cada paso, el nombre 
#de esa iteración se la asigne al primer elemento de la lista.
for (i in 1:length(filos)) {
  assign(filos_names[i], filos[[i]])
}

#estadistica
f <-subset(ps.melt_sum,ps.melt_sum$Phylum == 'Pseudomonadota')

normalidad_homocedasticidad(f,'Abundance','Group')
funcion_kruskal(f,'Abundance','Group')
boxplot(f$Abundance~f$Group)

#Actinobacteriota: mucho mas en Serious
#Campilobacterota solo en Serious
#Fusobacteriota no hay en Mild
#Proteobacteria un pocomas en Serious
#Synergistota solo en Serious

# Agrupar por Group y Phylum, y luego calcular la media y la desviación estándar de la abundancia
result <- ps.melt_sum %>%
  group_by(Group, Phylum) %>%
  summarise(`Relative Abundance` = mean(Abundance))
write.xlsx(result,'filo_abundance_stool.xlsx')


#GENERO
glomg <- tax_glom(ps.rel, taxrank = 'Genus', NArm = FALSE)
ps.meltg <- psmelt(glomg)
# change to character for easy-adjusted level
ps.meltg$Genus <- as.character(ps.meltg$Genus)

ps.meltg <- ps.meltg %>%
  group_by(Group,Genus) %>%
  mutate(median=median(Abundance))

ps.meltg_sum <- ps.meltg %>%
  group_by(Patient,Group,Genus) %>% #creamos una nueva variable "summarise" teniendo en cuenta estas tres que coincidan
  summarise(Abundance= sum(Abundance))

superiorg<-subset(ps.meltg,ps.meltg$median > 0.5)

superiorg <- superiorg %>%
  group_by(Group,Genus) %>% #para agrupar con las variables que queramos.
  mutate(RelativeAbundance= Abundance/sum(Abundance)) %>%
  ungroup() %>%
  mutate(Genus = as.factor(Genus))

genus<-ggplot(superiorg, aes(x = Group, y = RelativeAbundance, fill = Genus)) + 
  geom_bar(stat = "identity", position = position_fill()) + #se usa position fill para ajusar el eje y
  labs(x="", y="Relative abundance (%)") +
  #facet_wrap(~Group,scales = "fixed") +
  theme_classic() + 
  theme(strip.background = element_blank(), 
        axis.text.x.bottom = element_text(angle = 45,
                                          size = 8,
                                          hjust = 1,
                                          face = 'bold'),
        strip.text.x = element_text(size = 10)) +
  scale_fill_viridis_d()+
  scale_y_continuous(labels = scales::percent_format())
genus
tiff("genus_colores.tiff", width = 15, height = 6, units = "in", res = 300)
print(genus)
dev.off() 

#Separar cada genero y hacer estadística de esta forma para sacar las diferencias.
#Generamos una lista con x numero de filos mediante el comando split

generos <- split(superiorg,superiorg$Genus)
generos_names <- names(generos)

#hacemos un bucle que vaya de 1 al total de la lista y que en cada paso, el nombre 
#de esa iteración se la asigne al primer elemento de la lista.
for (i in 1:length(generos)) {
  assign(generos_names[i], generos[[i]])
}

#estadística
g <-subset(superiorg,superiorg$Genus == 'Veillonella')

normalidad_homocedasticidad(g,'Abundance','Group')
funcion_wilcoxon(g,'Abundance','Group')
boxplot(g$Abundance~g$Group)


# Crear una tabla vacía para almacenar los resultados finales
resultados <- data.frame(Genus = character(),
                         Abundance_Mild = numeric(),
                         Abundance_Moderate = numeric(),
                         Abundance_Severe = numeric(),
                         p_value_Severe_vs_Mild = numeric(),
                         p_value_Severe_vs_Moderate = numeric(),
                         p_value_Moderate_vs_Mild = numeric(),
                         stringsAsFactors = FALSE)

# Bucle para realizar las pruebas estadísticas para cada género en ps.melt_sum
for (i in 1:length(generos_names)) {
  genero_name <- generos_names[i]
  
  # Filtrar los datos del género actual en ps.melt_sum
  genero_data <- subset(ps.meltg_sum, Genus == genero_name)
  
  # Calcular la abundancia relativa media por grupo
  resumen <- genero_data %>%
    group_by(Group) %>%
    summarise(RelativeAbundance = mean(Abundance), .groups = 'drop') %>%
    pivot_wider(names_from = Group, values_from = RelativeAbundance, 
                names_prefix = "Abundance_")
  
  # Chequear normalidad y homocedasticidad
  normal <- normalidad_homocedasticidad(genero_data, 'Abundance', 'Group')
  
  # Realizar la prueba ANOVA o Kruskal-Wallis dependiendo de la normalidad
  if (normal) {
    post_hoc_results <- funcion_anova(genero_data, 'Abundance', 'Group')
  } else {
    post_hoc_results <- funcion_kruskal(genero_data, 'Abundance', 'Group')
  }
  
  # Inicializar valores de p-value en NA
  p_value_severe_vs_mild <- NA
  p_value_severe_vs_moderate <- NA
  p_value_moderate_vs_mild <- NA
  
  # Verificar los resultados post-hoc
  if (nrow(post_hoc_results) > 0) {
    comparisons <- post_hoc_results$Comparison
    p_values <- post_hoc_results$p_value
    
    # Asignar p-valores basados en el orden de las comparaciones
    if (length(p_values) >= 3) {
      p_value_severe_vs_mild <- p_values[1]  # Asumiendo el primer valor es Severe vs Mild
      p_value_severe_vs_moderate <- p_values[2]  # Asumiendo el segundo valor es Severe vs Moderate
      p_value_moderate_vs_mild <- p_values[3]  # Asumiendo el tercer valor es Moderate vs Mild
    }
  }
  
  # Combinar los resultados en una sola fila
  fila_resultado <- data.frame(Genus = genero_name,
                               Abundance_Mild = resumen$Abundance_Mild,
                               Abundance_Moderate = resumen$Abundance_Moderate,
                               Abundance_Severe = resumen$Abundance_Severe,
                               p_value_Severe_vs_Mild = p_value_severe_vs_mild,
                               p_value_Severe_vs_Moderate = p_value_severe_vs_moderate,
                               p_value_Moderate_vs_Mild = p_value_moderate_vs_mild,
                               stringsAsFactors = FALSE)
  
  # Añadir la fila a la tabla de resultados
  resultados <- rbind(resultados, fila_resultado)
}

# Ver los resultados finales
head(resultados)

                               
normalidad_homocedasticidad <- function(data, variable, grupo) {
  # Normalidad
  shapiro_tests <- by(data[[variable]], data[[grupo]], shapiro.test)
  normal <- all(sapply(shapiro_tests, function(x) x$p.value > 0.05))
  
  # Homocedasticidad
  levene_test <- leveneTest(data[[variable]] ~ data[[grupo]])
  homocedasticidad <- levene_test$`Pr(>F)`[1] > 0.05
  
  return(normal & homocedasticidad)
}

# Función para ANOVA
funcion_anova <- function(data, variable, grupo) {
  a_variable <- aov(data[[variable]] ~ data[[grupo]])
  summary_aov <- summary(a_variable)
  
  # Guardamos el p-value del ANOVA
  valor_p <- summary_aov[[1]]$`Pr(>F)`[1]
  
  if (valor_p <= 0.05) {
    post_hoc <- TukeyHSD(a_variable, grupo)
    post_hoc_df <- as.data.frame(post_hoc[[1]])
    post_hoc_df$Comparison <- rownames(post_hoc_df)
    post_hoc_df <- post_hoc_df[, c("Comparison", "p adj")]
    names(post_hoc_df) <- c("Comparison", "p_value")
  } else {
    post_hoc_df <- data.frame(Comparison = character(0),
                              p_value = numeric(0),
                              stringsAsFactors = FALSE)
    print("No hay diferencias significativas")
  }
  
  return(post_hoc_df)
}

funcion_kruskal <- function(data, variable, grupo) {
  test_k <- kruskal.test(data[[variable]] ~ data[[grupo]])
  
  # Guardamos el p-value del Kruskal-Wallis
  valor_pk <- test_k$p.value
  
  post_hoc_df <- data.frame(Comparison = character(), p_value = numeric(), stringsAsFactors = FALSE)
  
  if (valor_pk <= 0.05) {
    tryCatch({
      post_hoc <- dunn.test(x = data[[variable]], g = data[[grupo]], method = "bonferroni")
      post_hoc_df <- as.data.frame(post_hoc$P.adjusted)
      post_hoc_df$Comparison <- rownames(post_hoc_df)
      names(post_hoc_df) <- c("p_value", "Comparison")
    }, error = function(e) {
      message("Error en la prueba post-hoc: ", e$message)
    })
  } else {
    print("No hay diferencias significativas")
  }
  
  return(post_hoc_df)
}






# Agrupar por Group y Phylum, y luego calcular la media y la desviación estándar de la abundancia
result_g <- superiorg %>%
  group_by(Group, Genus) %>%
  summarise(RelativeAbundance = mean(Abundance)) %>%
  ungroup()
write.xlsx(resultados,'genus_abundance_stool.xlsx')
result <- ps.melt_sum %>%
  group_by(Group, Phylum) %>%
  summarise(`Relative Abundance` = mean(Abundance)) %>%
  ungroup()

#Diagrama de Venn

library(eulerr)
library(microbiomeutilities)

comp <- unique(as.character(meta(ps.rel)$Group))
print(comp)

list_core <- list()

for (n in comp) {
  ps.sub <- subset_samples(ps.rel, comp == n)
  
  core_m <- core_members(ps.sub,
                         detection = 0.1,
                         prevalence = 0.1)
  
  # Filtrar los core taxa para excluir los que contienen los términos excluidos
  
  print(paste0("No. of core taxa in ", n, " : ", length(core_m)))
  
  list_core[[n]] <- core_m
}

mycols <- c(`Mild`="blue", `Moderate`="green",`Severe`="red") 
dv<-plot(venn(list_core),
     fills = mycols)
dv
tiff("dv.tiff", width = 4, height = 4, units = "in", res = 300)
print(dv)
dev.off() 

mo<-do.call(cbind.data.frame,list_core[1])
s<-do.call(cbind.data.frame,list_core[3])
m<-do.call(cbind.data.frame,list_core[2])

`Mild`<-rownames(tax.clean2)
M<-cbind(`Mild`,tax.clean2)
M_buena<-dplyr::inner_join(M,m,by="Mild")

`Moderate`<-rownames(tax.clean2)
MO<-cbind(`Moderate`,tax.clean2)
MO_buena<-dplyr::inner_join(MO,mo,by="Moderate")

`Severe`<-rownames(tax.clean2)
S<-cbind(`Severe`,tax.clean2)
S_buena<-dplyr::inner_join(S,s,by="Severe")

write.xlsx(M_buena,"Mild.xlsx")
write.xlsx(S_buena,"Severe.xlsx")
write.xlsx(MO_buena,"Moderate.xlsx")


##DIFFERENTIAL ANALYSIS
#https://bioconductor.org/packages/devel/bioc/manuals/lefser/man/lefser.pdf

#LEFSE plot. En este caso daba problemas a la hora de normalizar puesto que decia que la
#media entre grupos eran numerciamente idénticas. 

library(microbial)
library(ggpubr)

o<-otu_table(ps.rarefied)
high_otu_idx<-colSums(o)/sum(o) >= 0.001 #he tenido qeu bajar el valor para que pudiese hacerse
high_otu<-taxa_names(ps.rarefied)[high_otu_idx]
ps.lefse<-prune_taxa(high_otu,ps.rarefied)
#hacemos el lefse analisis con la nueva variable
res2<-ldamarker(ps.lefse,group = "Group")

RES<-subset(res2,res2$rank == "Species")
#eliminamos los nombres para quedarnos solo con el genero y especie
RES$tax <- gsub("^(.*?_){6}", "", RES$tax)
#ahora eliminamos todos los que no están determinados
RES<- RES[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome|bacterium|intestinal",
                 RES$tax, ignore.case = TRUE), ]
RES <- RES %>%
  filter(!(LDAscore <= 5 & direction == "Severe"))
RES$tax <- gsub("Veillonella_ratti", "Veillonella_sp.", RES$tax)

lefse_plot<-plotLDA(RES,group = c("Mild","Moderate","Severe"),
                    lda = 4,padj = 0.001,color = c("green","blue","red"))+
  xlab("High dimensional biomarker") + 
  ylab("LDA SCORE (log10)") + 
  theme(axis.text.x=element_text(hjust=1, size=8, vjust=0.4, colour="black",
                                 face = 'italic')) +
  theme(axis.text.y=element_text(hjust=1, size=8, vjust=0.4, colour="black",
                                 face = 'italic')) +
  theme(axis.title.y=element_blank()) +
  theme(axis.title.x=element_text(size=7, colour="black")) +
  labs(fill="  Group\n") +
  #theme(legend.title =element_text(size=10, colour="black")) +
  #theme(legend.text = element_text(size=10, colour="black")) +
  guides(fill = guide_legend(override.aes = list(size=1)))+
  theme_classic()
lefse_plot

tiff("lefse.tiff", width = 6, height = 6, units = "in", res = 300)
print(lefse_plot)
dev.off() 
#ANALISIS DE CORRELACION

#hacemos lo mismo para la otra correlacion. Primero hacemos la selección de variables
#primero eliminamos las variables de no interes:
m_cor_heces<-metadata_heces[,-(1:3)]

factor_cols <- sapply(m_cor_heces, is.character)
for (i in names(m_cor_heces)[factor_cols]) {
  levels <- unique(m_cor_heces[[i]])
  m_cor_heces[[i]] <- as.integer(factor(m_cor_heces[[i]], levels = levels))
  attr(m_cor_heces[[i]], "labels") <- levels
}
str(m_cor_heces)

m_cor_heces<-m_cor_heces[,-(11:12)]

#cargamos el nuevo objeto PS
SAMPLE_cor <- sample_data(m_cor_heces)
ps_cor <- phyloseq(OTU,TAX,SAMPLE_cor,TREE)

set.seed(111) # keep result reproductive
ps.rarefied_cor = rarefy_even_depth(ps_cor, rngseed=1, sample.size=25000, replace=F)

#realizamos la correlacion para la clinica

hm_cor<- tax_filter(ps.rarefied_cor, min_prevalence = 0.5, min_sample_abundance = 1) %>%
  tax_fix(unknowns = c("uncultured"))
hm_cor <- tax_agg(hm_cor, "Genus")

set.seed(123)
taxa <- sample(tax_top(hm_cor, n = 10), size = 10)
ud <- 50

cor<-cor_heatmap(
  data = hm_cor, taxa = taxa,
  tax_anno = taxAnnotation(
    Prv. = anno_tax_prev(undetected = ud),
    Abd. = anno_tax_box(undetected = ud,
                        size = grid::unit(1,"cm"))
  ),
  width = grid::unit(130, "mm"), height = grid::unit(7, "cm"),
  heatmap_legend_param = list(
    at = -1:1,
    direction = "vertical", position = "center",
    legend_width = grid::unit(4, "cm"), grid_height = grid::unit(4, "mm")
  ))
cor
tiff("cor_stool.tiff", width = 9, height = 6, units = "in", res = 300)
print(cor)
dev.off()


##CORRELACIÓN CON LOS BIOMARCADORES DETECTADOS

#Buscamos la abundancia de dichas especies detectadas y la resumimos en una tabla

gloms <- tax_glom(ps.rel, taxrank = 'Species', NArm = FALSE)
ps.melts <- psmelt(gloms)
# change to character for easy-adjusted level
ps.melts$Species <- as.character(ps.melts$Species)

#nos quedamos con las columnas: OTU,Sample, Abundance, Patient, Group y species

correlacion <- ps.melts %>%
  select(OTU,Sample,Abundance,Patient,Group,Species)

#Ahora filtramos con los mismos valores que en lefse para eliminar datos no completos
correlacion<- correlacion[!grepl("unclassified|uncultured|unidentified|bacterium|intestinal",
                                 correlacion$Species, ignore.case = TRUE), ]

#creamos un vector con el nombre de las especies a filtrar
especies_filtrar <- c("Bacteroides_coprocola","Veillonella_ratti",
                      "Ruminococcus_bicirculans","Sutterella_stercoricanis",
                      "Prevotella_stercorea","Bacteroides_cellulosilyticus",
                      "Streptococcus_salivarius","Bacteroides_stercoris",
                      "Escherichia_sp.","Enterococcus_duran","Alistipes_onderdonkii",
                      "Prevotella_timonensis","Prevotella_copri","Prevotella_bivia")


#las seleccionamos en ps.mlet
correlacion_filtrado <- correlacion %>%
  filter(Species %in% especies_filtrar)
write.xlsx(correlacion_filtrado,"lefse_heces.xlsx")

# Calcular la abundancia relativa media por grupo y especie
result_heces_lefse <- correlacion_filtrado %>%
  group_by(Group, Species) %>%
  summarise(RelativeAbundance = mean(Abundance, na.rm = TRUE), .groups = 'drop')
write.xlsx(result_heces_lefse,"lefse_heces_abundance.xlsx")




#Juntamos ambos data frame y le damos forma

cor_biomarkers <- dplyr::inner_join(correlacion_filtrado,ps.melts, by="OTU")
cor_biomarkers <- cor_biomarkers[,-(2:6)]
cor_biomarkers <- cor_biomarkers[,-(2)]
cor_biomarkers <- cor_biomarkers[,-(3)]
cor_biomarkers <- cor_biomarkers[,-(4)]
cor_biomarkers <- cor_biomarkers[,-(23:29)]
cor_biomarkers <- cor_biomarkers[,-(14:15)]

#reordenamos las columnas y cambiamos nombre
library(dplyr)
library(reshape2)

cor_biomarkers <- cor_biomarkers %>%
  rename(
    Abundance = Abundance.y,
    Group = Group.y,
    Species = Species.y
  ) %>%
  select(Species, everything())
cor_biomarkers <- cor_biomarkers[,-2]
cor_biomarkers <- cor_biomarkers[,-3]
cor_biomarkers$Species <- gsub("Veillonella_ratti", "Veillonella_sp.", cor_biomarkers$Species)
# Definir los nombres de las especies
species_names <- unique(cor_biomarkers$Species)

#transformarmos a factor las columnas necesarias

factor_cols <- sapply(names(cor_biomarkers), function(col) is.character(cor_biomarkers[[col]]) && col != "Species")
for (i in names(cor_biomarkers)[factor_cols]) {
  levels <- unique(cor_biomarkers[[i]])
  cor_biomarkers[[i]] <- as.integer(factor(cor_biomarkers[[i]], levels = levels))
  attr(cor_biomarkers[[i]], "labels") <- levels
}
str(cor_biomarkers)

# Crear una lista de nombres de especies únicos
species_names <- unique(cor_biomarkers$Species)

# Crear una lista para almacenar las correlaciones y los valores p por especie
correlations_by_species <- list()
pvalues_by_species <- list()
cor_variables <- colnames(cor_biomarkers[-1])
cor_variables <- cor_variables[-1]

# Calcular las correlaciones y los valores p para cada especie
for (species in species_names) {
  subset_data <- subset(cor_biomarkers, Species == species)  # Subset de la especie actual
  
  # Asegurarse de que todas las columnas sean numéricas
  subset_data <- subset_data %>%
    mutate(across(all_of(cor_variables), as.numeric))
  
  # Inicializar listas para esta especie
  species_correlations <- c()
  species_pvalues <- c()
  
  for (var in cor_variables) {
    test_result <- cor.test(subset_data$Abundance, subset_data[[var]], method = "spearman", use = "pairwise.complete.obs")
    species_correlations <- c(species_correlations, test_result$estimate)
    species_pvalues <- c(species_pvalues, test_result$p.value)
  }
  
  correlations_by_species[[species]] <- setNames(species_correlations, cor_variables)
  pvalues_by_species[[species]] <- setNames(species_pvalues, cor_variables)
}

# Convertir las listas de correlaciones y p-values a DataFrames con nombres originales
correlations_df <- do.call(rbind, lapply(names(correlations_by_species), function(species) {
  data.frame(Species = species, t(correlations_by_species[[species]]))
}))
pvalues_df <- do.call(rbind, lapply(names(pvalues_by_species), function(species) {
  data.frame(Species = species, t(pvalues_by_species[[species]]))
}))

# Convertir los DataFrames a formato largo
correlations_df_long <- melt(correlations_df, id.vars = "Species")
pvalues_df_long <- melt(pvalues_df, id.vars = "Species")

# Ajustar los nombres de las variables
colnames(correlations_df_long) <- c("Species", "Variable", "Correlation")
colnames(pvalues_df_long) <- c("Species", "Variable", "P.value")
combined_df <- merge(correlations_df_long, pvalues_df_long, by = c("Species", "Variable"))
# Escribir el DataFrame a un archivo Excel
write.xlsx(combined_df, 'correlation_values_with_pvalues_s.xlsx')

# Filtrar las correlaciones que son significativas (p < 0.05) y elevadas (|correlation| > 0.25)
significant_correlations <- correlations_df_long %>%
  inner_join(pvalues_df_long, by = c("Species", "Variable")) %>%
  filter(P.value < 0.05 & (Correlation <= -0.25 | Correlation >= 0.4))
write.xlsx(significant_correlations, 'correlation_values_with_pvalues_s.xlsx')
# Crear el heatmap con todas las correlaciones
cor_bm_s <- ggplot(correlations_df_long, aes(x = Species, y = Variable, fill = Correlation)) +
  geom_tile() +
  scale_fill_gradient(low = "grey", high = "yellow") +
  labs(fill = "Spearman") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 55, hjust = 1, size = 8, face = "bold"),
        axis.text.y = element_text(size = 8, face = "bold"),
        legend.title = element_text(face = "bold"))

# Agregar asteriscos en las celdas con correlaciones significativamente altas o bajas
cor_bm_s <- cor_bm_s + 
  geom_text(data = significant_correlations, aes(label = "*"), color = "red", size = 3, vjust = 0.5, hjust = 0.5)
cor_bm_s
tiff("cor_biomarkers_s.tiff", width = 7, height = 4, units = "in", res = 300)
print(cor_bm_s)
dev.off() 
