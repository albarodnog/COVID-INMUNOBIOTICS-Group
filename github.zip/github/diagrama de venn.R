library(xlsx)
library(dplyr)

setwd("")

mild <- read.xlsx("",sheetIndex = 1,header = TRUE)
moderate <- read.xlsx("",sheetIndex = 2,header = TRUE)
severe <- read.xlsx("",sheetIndex = 3,header = TRUE)

#los que coinciden entre los 3
mild_moderate <- inner_join(mild, moderate, by = "feature")
mild_moderate<-mild_moderate[,-(9:15)]
mild_moderate_severe <- inner_join(mild_moderate,severe,by="feature")
mild_moderate_severe <- mild_moderate_severe[,-(9:15)]

# Comparación entre mild, moderate
dif_mvsmo <- anti_join(mild_moderate,mild_moderate_severe)

# Comparación entre mild y severe
mild_severe <- inner_join(mild, severe, by = "feature")
mild_severe <- mild_severe[,-(9:15)]
dif_mvss <- anti_join(mild_severe,mild_moderate_severe)

# Comparación entre moderate y severe
moderate_severe <- inner_join(moderate, severe, by = "feature")
moderate_severe <- moderate_severe[,-(9:15)]
dif_movss <- anti_join(moderate_severe,mild_moderate_severe)

#solo mild
mild_comparaciones <- rbind(mild_moderate_severe,dif_mvsmo)
mild_comparaciones <- rbind(mild_comparaciones,dif_mvss)
s_mild <- anti_join(mild,mild_comparaciones)

#solo moderate
mo_comparaciones <- rbind(mild_moderate_severe,dif_mvsmo)
mo_comparaciones <- rbind(mo_comparaciones,dif_movss)
s_moderate <- anti_join(moderate,mo_comparaciones)

#solo severe
s_comparaciones <- rbind(mild_moderate_severe,dif_mvss)
s_comparaciones <- rbind(s_comparaciones,dif_movss)
s_severe <- anti_join(severe,s_comparaciones)

#eliminamos los que no esten bien determinados para cada tabla
dif_mvsmo<- dif_mvsmo[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                             dif_mvsmo$Species.x, ignore.case = TRUE), ]

dif_mvss <- dif_mvss[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                            dif_mvss$Species.x, ignore.case = TRUE), ]

dif_movss <- dif_movss[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                              dif_movss$Species.x, ignore.case = TRUE), ]

s_mild <- s_mild[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                              s_mild$Species, ignore.case = TRUE), ]

s_moderate <- s_moderate[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                        s_moderate$Species, ignore.case = TRUE), ]

s_severe <- s_severe[!grepl("unclassified|uncultured|unidentified|group|gut|metagenome", 
                        s_severe$Species, ignore.case = TRUE), ]

write.xlsx(dif_mvsmo,"MildvsModerate.xlsx")
write.xlsx(dif_mvss,"MildvsSerious.xlsx")
write.xlsx(dif_movss,"ModeratevsSerious.xlsx")
write.xlsx(s_mild,"s_mild.xlsx")
write.xlsx(s_moderate,"s_moderate.xlsx")
write.xlsx(s_severe,"s_severe.xlsx")
